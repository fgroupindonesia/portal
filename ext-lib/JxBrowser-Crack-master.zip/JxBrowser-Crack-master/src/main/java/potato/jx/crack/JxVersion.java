package potato.jx.crack;

/**
 * @author zh_zhou
 * created at 2018/11/19 09:45
 * Copyright [2018] [zh_zhou]
 */
public enum  JxVersion {
    V6_09,
    V6_18,
    V6_22;
}
